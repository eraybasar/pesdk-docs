---
layout: guides/ios/v6_5/content
title: &title Overlays # title as shown in the menu and 

menuitem: *title
order: 1
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - feature
tags: &tags # tags that are necessary
  - photo editor 

published: false # Either published or not 
---

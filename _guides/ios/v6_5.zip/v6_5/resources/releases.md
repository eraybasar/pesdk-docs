---
published: true # Either published or not 
layout: guides/ios/v6_5/content
title: &title Releases # title as shown in the menu and 

menuitem: *title
order: 2
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - resource
tags: &tags # tags that are necessary
  - photo editor 
redirect_to: 
  - https://github.com/imgly/pesdk-ios-build/releases
---

# {{page.title}}

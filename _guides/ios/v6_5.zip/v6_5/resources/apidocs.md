---
layout: guides/ios/v6_5/content
title: &title Api Docs # title as shown in the menu and 

menuitem: *title
order: 1
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - resource
tags: &tags # tags that are necessary
  - photo editor 

published: true # Either published or not 

redirect_to: 
  - https://static.photoeditorsdk.com/docs/ios/
---

---
published: true # Either published or not 
layout: guides/ios/v6_5/content
title: &title Support # title as shown in the menu and 

menuitem: *title
order: 4
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - resource
tags: &tags # tags that are necessary
  - photo editor 
redirect_to: 
  - https://support.photoeditorsdk.com

---

# {{page.title}}

---
layout: guides/ios/v6_5/content
title: &title Getting Started # title as shown in the menu and 
order: 1
menuitem: *title
platform:
  - ios
category: 
  - guide

tags: &tags # tags that are necessary
  - photo editor 

published: true # Either published or not 
redirect_to:
  - '/guides/ios/v6_5/ui/controls'
---

---
layout: guides/ios/v6_5/content
title: &title Architecture # title as shown in the menu and 

menuitem: *title
order: 2
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - introduction

tags: &tags # tags that are necessary
  - photo editor 

status: draft
---

# Architecture



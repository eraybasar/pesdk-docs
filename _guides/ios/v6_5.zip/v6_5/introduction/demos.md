---
layout: guides/ios/v6_5/content
title: &title Demos # title as shown in the menu and 

menuitem: *title
order: 4
platform:
  - ios
version:
  - v6_5
category: 
  - guide
  - introduction

tags: &tags # tags that are necessary
  - photo editor 

published: true
---

# Demos


